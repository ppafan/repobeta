/**
 * Created by dathq on 28/11/2017.
 */
var config = {
    map: {
        '*': {
            azipcode: 'Acommerce_Address/js/form/element/zipcode',
            acommerceform:'Acommerce_Address/js/form',
            'Magento_Ui/js/form/element/select':'Acommerce_Address/js/form/element/select'
        }
    }
};
